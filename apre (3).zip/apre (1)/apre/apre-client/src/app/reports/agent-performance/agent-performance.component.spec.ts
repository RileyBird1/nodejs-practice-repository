import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, Input } from '@angular/core';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { environment } from '../../../environments/environment';

import { CommonModule } from '@angular/common';




const mockData = [
  { agentId: 'A1', name: 'Alice', calls: 120, avgDuration: 300, rating: 4.7 },
  { agentId: 'A2', name: 'Bob', calls: 95, avgDuration: 250, rating: 4.2 }
];

import { AgentPerformanceComponent } from './agent-performance.component';

describe('AgentPerformanceComponent', () => {
  let component: AgentPerformanceComponent;
  let fixture: ComponentFixture<AgentPerformanceComponent>;

  beforeEach(async () => {
    // Mock ChartComponent and TableComponent as standalone components for imports
    // Mock ChartComponent as a standalone component to prevent Chart.js errors in the test environment.
    // This mock provides all @Input bindings used in the real component's template, so Angular's binding checks pass.
    @Component({selector: 'app-chart', standalone: true, template: ''})
    class MockChartComponent {
      // Accepts chart data (number[]), but does nothing in the mock.
      @Input() data: any;
      // Accepts chart label (string), but does nothing in the mock.
      @Input() label: any;
      // Accepts chart type (string), but does nothing in the mock.
      @Input() type: any;
      // Accepts chart labels (string[]), but does nothing in the mock.
      @Input() labels: any;
    }
    // Mock TableComponent as a standalone component to prevent errors from missing table bindings in the test environment.
    // This mock provides all @Input bindings used in the real component's template, so Angular's binding checks pass.
    @Component({selector: 'app-table', standalone: true, template: ''})
    class MockTableComponent {
      // Accepts table data (array of objects), but does nothing in the mock.
      @Input() data: any;
      // Accepts table title (string), but does nothing in the mock.
      @Input() title: any;
      // Accepts table headers (string[]), but does nothing in the mock.
      @Input() headers: any;
      // Accepts records per page (number), but does nothing in the mock.
      @Input() recordsPerPage: any;
      // Accepts sortable columns (string[]), but does nothing in the mock.
      @Input() sortableColumns: any;
      // Accepts header background (string), but does nothing in the mock.
      @Input() headerBackground: any;
    }
    await TestBed.configureTestingModule({
      imports: [AgentPerformanceComponent, HttpClientTestingModule, CommonModule]
    }).compileComponents();
    // Override the imports of AgentPerformanceComponent to use mocks
    TestBed.overrideComponent(AgentPerformanceComponent, {
      set: {
        imports: [CommonModule, MockChartComponent, MockTableComponent]
      }
    });
    fixture = TestBed.createComponent(AgentPerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // Test to ensure the component is created successfully.
  // This is a basic sanity check to verify that the Angular component instantiates without errors.
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

describe('AgentPerformanceComponent (extended)', () => {
  let component: any;
  let fixture: any;
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    // Mock ChartComponent and TableComponent as standalone components for imports
    // Mock ChartComponent as a standalone component to prevent Chart.js errors in the test environment.
    // This mock provides all @Input bindings used in the real component's template, so Angular's binding checks pass.
    @Component({selector: 'app-chart', standalone: true, template: ''})
    class MockChartComponent {
      // Accepts chart data (number[]), but does nothing in the mock.
      @Input() data: any;
      // Accepts chart label (string), but does nothing in the mock.
      @Input() label: any;
      // Accepts chart type (string), but does nothing in the mock.
      @Input() type: any;
      // Accepts chart labels (string[]), but does nothing in the mock.
      @Input() labels: any;
    }
    // Mock TableComponent as a standalone component to prevent errors from missing table bindings in the test environment.
    // This mock provides all @Input bindings used in the real component's template, so Angular's binding checks pass.
    @Component({selector: 'app-table', standalone: true, template: ''})
    class MockTableComponent {
      // Accepts table data (array of objects), but does nothing in the mock.
      @Input() data: any;
      // Accepts table title (string), but does nothing in the mock.
      @Input() title: any;
      // Accepts table headers (string[]), but does nothing in the mock.
      @Input() headers: any;
      // Accepts records per page (number), but does nothing in the mock.
      @Input() recordsPerPage: any;
      // Accepts sortable columns (string[]), but does nothing in the mock.
      @Input() sortableColumns: any;
      // Accepts header background (string), but does nothing in the mock.
      @Input() headerBackground: any;
    }
    await TestBed.configureTestingModule({
      imports: [AgentPerformanceComponent, HttpClientTestingModule, CommonModule]
    }).compileComponents();
    // Override the imports of AgentPerformanceComponent to use mocks
    TestBed.overrideComponent(AgentPerformanceComponent, {
      set: {
        imports: [CommonModule, MockChartComponent, MockTableComponent]
      }
    });
    fixture = TestBed.createComponent(AgentPerformanceComponent);
    component = fixture.componentInstance;
    httpMock = TestBed.inject(HttpTestingController);
  });


  // Test to verify that agent data is fetched from the API and stored in the component.
  // This ensures the HTTP GET request is made and the response is processed correctly.
  it('should fetch and display agent data', () => {
    fixture.detectChanges();
    const req = httpMock.expectOne(`${environment.apiBaseUrl}/reports/agent-performance`);
    req.flush(mockData);
    expect(component.agentData.length).toBe(2);
    httpMock.verify();
  });


  // Test to ensure the component handles API errors gracefully.
  // This simulates a network error and checks that an error message is set on the component.
  it('should handle API error', () => {
    fixture.detectChanges();
    const req = httpMock.expectOne(`${environment.apiBaseUrl}/reports/agent-performance`);
    req.error(new ErrorEvent('Network error'));
    expect(component.errorMessage).toContain('Failed');
    httpMock.verify();
  });


  // Test to verify the toggleView method switches between 'chart' and 'table' views.
  // This ensures the UI can switch display modes as intended.
  it('should toggle view', () => {
    expect(component.view).toBe('chart');
    component.toggleView();
    expect(component.view).toBe('table');
    component.toggleView();
    expect(component.view).toBe('chart');
  });
});
