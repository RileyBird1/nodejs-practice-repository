/**
 * Author: Professor Krasso
 * Date: 10 September 2024
 * File: agent-performance.component.ts
 * Description: Agent performance component
 */
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ChartComponent } from '../../shared/chart/chart.component';
import { TableComponent } from '../../shared/table/table.component';
import { environment } from '../../../environments/environment';

// Agent performance data interface for type safety
interface AgentPerformance {
  agentId: string;
  name: string;
  calls: number;
  avgDuration: number;
  rating: number;
}

@Component({
  selector: 'app-agent-performance',
  standalone: true,
  // Added CommonModule, ChartComponent, and TableComponent to imports so template features and custom components work
  imports: [CommonModule, ChartComponent, TableComponent],
  // Inline template for agent performance view
  template: `
    <div>
      <h1>Agent Performance</h1>
      <button (click)="toggleView()">Switch to {{ view === 'chart' ? 'Table' : 'Chart' }}</button>
      <div *ngIf="errorMessage" class="message message--error">{{ errorMessage }}</div>
      <ng-container *ngIf="!errorMessage">
        <!-- Passes only call counts to chart for correct input type -->
        <app-chart *ngIf="view === 'chart'" [data]="chartData"></app-chart>
        <!-- Passes full agent data to table for tabular display -->
        <app-table *ngIf="view === 'table'" [data]="agentData"></app-table>
      </ng-container>
    </div>
  `,
  // Inline styles for component
  styles: [`
    h1 {
      font-size: 2rem;
      margin-bottom: 1rem;
    }
    .message--error {
      color: #b00;
      margin: 1rem 0;
    }
    button {
      margin-bottom: 1rem;
    }
  `]
})
export class AgentPerformanceComponent {
  agentData: AgentPerformance[] = [];
  errorMessage = '';
  view: 'chart' | 'table' = 'chart';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    // Fetch agent performance data from API on component init
    this.http.get<AgentPerformance[]>(`${environment.apiBaseUrl}/reports/agent-performance`).subscribe({
      next: data => this.agentData = data,
      error: err => this.errorMessage = 'Failed to load agent performance data.'
    });
  }

  // Toggle between chart and table view for user preference
  toggleView() {
    this.view = this.view === 'chart' ? 'table' : 'chart';
  }

  // Returns an array of call counts for chart display (ChartComponent expects number[])
  get chartData(): number[] {
    return this.agentData.map(a => a.calls);
  }
}
