/**
 * Author: Professor Krasso
 * Date: 8/14/24
 * File: index.js
 * Description: Apre agent performance API for the agent performance reports
 */

'use strict';

const express = require('express');
const { mongo } = require('../../../utils/mongo');
const createError = require('http-errors');

const router = express.Router();

/**
 * @description
 *
 * GET /call-duration-by-date-range
 *
 * Fetches call duration data for agents within a specified date range.
 *
 * Example:
 * fetch('/call-duration-by-date-range?startDate=2023-01-01&endDate=2023-01-31')
 *  .then(response => response.json())
 *  .then(data => console.log(data));
 */
router.get('/call-duration-by-date-range', (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;

    if (!startDate || !endDate) {
      return next(createError(400, 'Start date and end date are required'));
    }

    console.log('Fetching call duration report for date range:', startDate, endDate);

    mongo(async db => {
      const data = await db.collection('agentPerformance').aggregate([
        {
          $match: {
            date: {
              $gte: new Date(startDate),
              $lte: new Date(endDate)
            }
          }
        },
        {
          $lookup: {
            from: 'agents',
            localField: 'agentId',
            foreignField: 'agentId',
            as: 'agentDetails'
          }
        },
        {
          $unwind: '$agentDetails'
        },
        {
          $group: {
            _id: '$agentDetails.name',
            totalCallDuration: { $sum: '$callDuration' }
          }
        },
        {
          $project: {
            _id: 0,
            agent: '$_id',
            callDuration: '$totalCallDuration'
          }
        },
        {
          $group: {
            _id: null,
            agents: { $push: '$agent' },
            callDurations: { $push: '$callDuration' }
          }
        },
        {
          $project: {
            _id: 0,
            agents: 1,
            callDurations: 1
          }
        }
      ]).toArray();

      res.send(data);
    }, next);
  } catch (err) {
    console.error('Error in /call-duration-by-date-range', err);
    next(err);
  }
});

/**
 * @description
 *
 * GET /
 *
 * Fetches overall agent performance data (mocked for demo)
 *
 * Example:
 * fetch('/api/reports/agent-performance')
 *  .then(response => response.json())
 *  .then(data => console.log(data));
 *
 * Added for Angular dashboard integration: allows the frontend to fetch summary agent performance data for chart/table display.
 */
router.get('/', (req, res, next) => {
  try {
    // In production, fetch from DB. Here, return mock data for demo/testing.
    // This endpoint was added to support the Angular agent performance dashboard.
    const data = [
      { agentId: 'A1', name: 'Alice', calls: 120, avgDuration: 300, rating: 4.7 },
      { agentId: 'A2', name: 'Bob', calls: 95, avgDuration: 250, rating: 4.2 },
      { agentId: 'A3', name: 'Charlie', calls: 110, avgDuration: 320, rating: 4.9 }
    ];
    res.json(data);
  } catch (err) {
    console.error('Error in /api/reports/agent-performance', err);
    next(err);
  }
});

module.exports = router;